from machine import Pin, time_pulse_us
from time import sleep

trig = Pin(20, Pin.OUT)
echo = Pin(19, Pin.IN)
distancia = []

#Pinos dos segmentos
#Centenas
display_1 = [
    Pin(0, Pin.OUT), #A
    Pin(1, Pin.OUT), #B
    Pin(6, Pin.OUT), #C
    Pin(4, Pin.OUT), #D
    Pin(5, Pin.OUT), #E
    Pin(2, Pin.OUT), #F
    Pin(3, Pin.OUT) #G
]

#Dezenas
display_2 = [
    Pin(7, Pin.OUT), #A
    Pin(8, Pin.OUT), #B
    Pin(13, Pin.OUT), #C
    Pin(12, Pin.OUT), #D
    Pin(11, Pin.OUT), #E
    Pin(9, Pin.OUT), #F
    Pin(10, Pin.OUT) #G
]

#Unidades
display_3 = [
    Pin(27, Pin.OUT), #A
    Pin(28, Pin.OUT), #B
    Pin(26, Pin.OUT), #C
    Pin(22, Pin.OUT), #D
    Pin(21, Pin.OUT), #E
    Pin(15, Pin.OUT), #F
    Pin(14, Pin.OUT) #G
]

#Numeros
numeros = [
  [0,0,0,0,0,0,1], #zero
  [1,0,0,1,1,1,1], #um
  [0,0,1,0,0,1,0], #dois
  [0,0,0,0,1,1,0], #tres
  [1,0,0,1,1,0,0], #quatro
  [0,1,0,0,1,0,0], #cinco
  [0,1,0,0,0,0,0], #seis
  [0,0,0,1,1,1,1], #sete
  [0,0,0,0,0,0,0], #oito
  [0,0,0,1,1,0,0] #nove
]

def display(dp, num):
    for i in range(7):
        dp[i].value(numeros[num][i])

while True:
    trig.value(1)
    trig.value(0)
    pulse = time_pulse_us(echo, Pin.high)
    if len(distancia)<5:
        distancia.append(round(34000*pulse/(2*1000000)))
    else:
        distancia.pop(0)
        distancia.append(round(34000*pulse/(2*1000000)))
    media = sum(distancia)/len(distancia)
    for i in distancia:
        soma=(i-media)**2
    desvio_padrao = (soma/len(distancia))**0.5
    print(distancia, "media:", media, "desvio padrão:", desvio_padrao)

    medint = int(media)
    display_3_valor = medint % 10
    display_2_valor = (medint % 100) // 10
    display_1_valor = medint // 100

    display(display_3, display_3_valor)
    display(display_2, display_2_valor)
    display(display_1, display_1_valor)
    sleep(1)