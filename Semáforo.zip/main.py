from machine import Pin
from time import sleep

vermelho = Pin(0,Pin.OUT)
amarelo = Pin(5,Pin.OUT)
verde = Pin(11,Pin.OUT)

while True:
    vermelho.on()
    sleep(5)
    vermelho.off()
    sleep(0.2)
    amarelo.on()
    sleep(2)
    amarelo.off()
    sleep(0.2)
    verde.on()
    sleep(5)
    verde.off()
    sleep(0.2)
