from machine import Pin 
from time import sleep

botao = Pin(0,Pin.IN,Pin.PULL_UP)

display = [
Pin(12, Pin.OUT), #A
Pin(13, Pin.OUT), #B
Pin(9, Pin.OUT), #C
Pin(8, Pin.OUT), #D
Pin(7, Pin.OUT), #E
Pin(11, Pin.OUT), #F
Pin(10, Pin.OUT) #G
]

display2 = [
Pin(4, Pin.OUT), #A
Pin(6, Pin.OUT), #B
Pin(16, Pin.OUT), #C
Pin(17, Pin.OUT), #D
Pin(18, Pin.OUT), #E
Pin(3, Pin.OUT), #F
Pin(2, Pin.OUT) #G
]

numeros = [
  [0,0,0,0,0,0,1], #zero
  [1,0,0,1,1,1,1], #um
  [0,0,1,0,0,1,0], #dois
  [0,0,0,0,1,1,0], #tres
  [1,0,0,1,1,0,0], #quatro
  [0,1,0,0,1,0,0], #cinco
  [0,1,0,0,0,0,0], #seis
  [0,0,0,1,1,1,1], #sete
  [0,0,0,0,0,0,0], #oito
  [0,0,0,1,1,0,0] #nove
]

contador = 0
contador2 = 0
auxiliar = 0

#reset
for i in range(7):
  display[i].value(1)
for i in range(7):
  display2[i].value(1)

while True:
 if botao.value()==0 and auxiliar == 0:
    #print("Apertou")
    for lista in numeros:
      for i in range(7):
        display[i].value(numeros[contador][i])
      for i in range(7):
        display2[i].value(numeros[contador2][i])
    auxiliar = 1
    contador = contador + 1
    if contador > 9:
       contador = 0
       contador2 = contador2 + 1
       if contador2 > 9:
          contador2 = 0
 elif botao.value()==1:
    #print("Não apertou")
    auxiliar = 0
 sleep(0.075)