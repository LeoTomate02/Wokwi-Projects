from modelagem import regressao_linear
from machine import Pin, time_pulse_us
from time import sleep

led_verm = Pin(0, Pin.OUT)
led_azul = Pin(2, Pin.OUT)

trigger = Pin(28, Pin.OUT)
echo = Pin(27, Pin.IN)
distancia = []

tempo = []
cont_temp = 0

while True:
    trigger.value(1)
    trigger.value(0)
    pulso = time_pulse_us(echo, Pin.high)
    if len(distancia)<10:
        distancia.append(round(34000*pulso/(2*1000000)))
        tempo.append(cont_temp)
    else:
        distancia.pop(0)
        tempo.pop(0)
        distancia.append(round(34000*pulso/(2*1000000)))
        tempo.append(cont_temp)
        c2,c1 = regressao_linear(tempo,distancia)
        print("y="+str(c2)+"*x+"+str(c1))
        if c2<0:
            led_verm.value(0)
            led_azul.value(1)
        if c2>0:
            led_verm.value(1)
            led_azul.value(0)
    cont_temp = cont_temp + 1
    
    print(distancia)
    print(tempo)

    sleep(1)
