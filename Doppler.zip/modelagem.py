def regressao_linear(x,y):
    if len(x)==len(y):
        m = len(x)

        soma_x = 0
        for i in x:
            soma_x+=i 
        
        soma_x_quadrado = 0
        for i in x:
            soma_x_quadrado+=i*i 

        soma_y = 0
        for j in y:
            soma_y+=j 
        
        soma_x_y = 0
        for n in range(m):
            soma_x_y += x[n]*y[n]

        numerador_c1 = soma_y*soma_x_quadrado - soma_x*soma_x_y
        numerador_c2 = m*soma_x_y - soma_y*soma_x
        denominador = m*soma_x_quadrado - soma_x*soma_x

        c1 = numerador_c1/denominador
        c2 = numerador_c2/denominador

        return [c2,c1]
    else:
        print("Erro")
        print("Comprimento X:", len(x))
        print("Comprimento Y:", len(y))
        return [0,0]